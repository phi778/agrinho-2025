let larguraCelula = 20; // Tamanho de cada "quadrado" no labirinto
let colunas;
let linhas;

let labirinto; // Matriz que representará o labirinto

let pacman;
let comida = []; // Array para armazenar todos os pontos de comida
let fantasmas = [];

let score = 0;
let vidas = 3;
let gameState = "start"; // "start", "playing", "gameover", "win"

// Imagens (se quiser adicionar gráficos personalizados)
let pacmanImg, fantasmaVermelhoImg, paredeImg, comidaImg;

function preload() {
    // Carregue imagens e sons aqui
    // Ex: pacmanImg = loadImage('assets/pacman.png');
    // Ex: somComer = loadSound('assets/comer.mp3');
}

function setup() {
    createCanvas(600, 600); // Tamanho da tela, ajuste conforme o labirinto

    colunas = width / larguraCelula;
    linhas = height / larguraCelula;

    // Inicializa o labirinto (será preenchido na função criarLabirinto)
    labirinto = [];

    // Cria o labirinto e a comida
    criarLabirinto();
    criarPacMan();
    criarFantasmas();
}

function draw() {
    background(0); // Fundo preto

    if (gameState === "start") {
        mostrarTelaInicio();
    } else if (gameState === "playing") {
        desenharLabirinto();
        desenharComida();
        pacman.update();
        pacman.show();
        pacman.checarComida(); // Checa se o Pac-Man comeu algum ponto

        for (let fantasma of fantasmas) {
            fantasma.update();
            fantasma.show();
            // Checar colisão do fantasma com Pac-Man
            if (pacman.colideCom(fantasma)) {
                // Lógica de colisão: Pac-Man perde vida ou fantasma é comido
                // Depende se o Pac-Man está com poder ou não
                lidarColisaoPacManFantasma(fantasma);
            }
        }

        mostrarHUD(); // Score e Vidas
        checarVitoriaDerrota();

    } else if (gameState === "gameover") {
        mostrarTelaFimJogo("Você Perdeu!");
    } else if (gameState === "win") {
        mostrarTelaFimJogo("Você Venceu!");
    }
}

function keyPressed() {
    if (gameState === "start" && keyCode === ENTER) {
        gameState = "playing";
    } else if (gameState === "playing") {
        pacman.setDirecao(keyCode);
    }
}

// --- Funções de Estado do Jogo ---

function mostrarTelaInicio() {
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(48);
    text("PAC-MAN", width / 2, height / 2 - 50);
    textSize(24);
    text("Pressione ENTER para começar", width / 2, height / 2 + 20);
}

function mostrarTelaFimJogo(mensagem) {
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(48);
    text(mensagem, width / 2, height / 2 - 50);
    textSize(24);
    text("Pressione F5 para reiniciar", width / 2, height / 2 + 20);
}

function mostrarHUD() {
    fill(255);
    textSize(20);
    textAlign(LEFT, TOP);
    text("Score: " + score, 10, 10);
    textAlign(RIGHT, TOP);
    text("Vidas: " + vidas, width - 10, 10);
}

function checarVitoriaDerrota() {
    if (vidas <= 0) {
        gameState = "gameover";
    }

    // Checar se todas as comidas foram pegas
    let todasComidasPegas = true;
    for (let p of comida) {
        if (!p.comido) {
            todasComidasPegas = false;
            break;
        }
    }
    if (todasComidasPegas) {
        gameState = "win";
    }
}

// --- Labirinto ---

function criarLabirinto() {
    // Exemplo de um labirinto simples (1 = parede, 0 = caminho, 2 = comida, 3 = power pellet)
    // Você pode criar um labirinto mais complexo ou usar um algoritmo de geração de labirinto
    // Este é apenas um exemplo de matriz de teste:
    let mapa = [
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1],
        [1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1],
        [1, 3, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1], // Exemplo de power pellet
        [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1],
        [1, 2, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1],
        [1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 1, 1, 1],
        [1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1], // Centro para fantasmas (0)
        [1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1], // Casa dos fantasmas (0)
        [1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1],
        [1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1],
        [1, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 1, 1, 1],
        [1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1],
        [1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 1, 1, 1],
        [1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1],
        [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1],
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    ];

    // Ajusta o tamanho da tela dinamicamente ao labirinto
    createCanvas(mapa[0].length * larguraCelula, mapa.length * larguraCelula);
    colunas = mapa[0].length;
    linhas = mapa.length;

    for (let i = 0; i < linhas; i++) {
        labirinto[i] = [];
        for (let j = 0; j < colunas; j++) {
            labirinto[i][j] = mapa[i][j];
            if (mapa[i][j] === 2) {
                comida.push(new Comida(j * larguraCelula + larguraCelula / 2, i * larguraCelula + larguraCelula / 2, false));
            } else if (mapa[i][j] === 3) {
                comida.push(new Comida(j * larguraCelula + larguraCelula / 2, i * larguraCelula + larguraCelula / 2, true)); // Power Pellet
            }
        }
    }
}

function desenharLabirinto() {
    for (let i = 0; i < linhas; i++) {
        for (let j = 0; j < colunas; j++) {
            if (labirinto[i][j] === 1) { // Parede
                fill(0, 0, 255); // Azul
                // stroke(0, 0, 200); // Borda mais escura
                noStroke();
                rect(j * larguraCelula, i * larguraCelula, larguraCelula, larguraCelula);
            }
            // Não desenhamos 0, 2 ou 3 aqui, pois são caminhos e comida
        }
    }
}

// --- Comida ---

class Comida {
    constructor(x, y, isPowerPellet) {
        this.x = x;
        this.y = y;
        this.raio = isPowerPellet ? larguraCelula / 3 : larguraCelula / 6;
        this.isPowerPellet = isPowerPellet;
        this.comido = false;
    }

    show() {
        if (!this.comido) {
            noStroke();
            if (this.isPowerPellet) {
                fill(255, 255, 0); // Amarelo para power pellets
            } else {
                fill(255, 255, 255); // Branco para comida normal
            }
            ellipse(this.x, this.y, this.raio * 2, this.raio * 2);
        }
    }
}

function desenharComida() {
    for (let p of comida) {
        p.show();
    }
}

// --- Pac-Man ---

class PacMan {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.raio = larguraCelula / 2 - 2; // Ajuste para não colar nas paredes
        this.velocidade = 2; // Velocidade do Pac-Man
        this.dx = 0;
        this.dy = 0;
        this.proximoDx = 0; // Para prever a próxima direção
        this.proximoDy = 0;
        this.anguloInicialBoca = PI / 4;
        this.anguloFinalBoca = 2 * PI - PI / 4;
        this.aberturaBoca = 0; // 0 para boca fechada, 1 para boca aberta
        this.velocidadeBoca = 0.1;
        this.direcaoAtualBoca = 1; // 1 abrindo, -1 fechando
        this.anguloRotacao = 0; // Para rotacionar o Pac-Man

        this.estaComPoder = false;
        this.tempoPoderRestante = 0;
        this.duracaoPoder = 300; // Frames de duração do poder
    }

    setDirecao(keyCode) {
        let novaDx = 0;
        let novaDy = 0;

        if (keyCode === LEFT_ARROW) {
            novaDx = -1;
            this.anguloRotacao = PI; // Esquerda
        } else if (keyCode === RIGHT_ARROW) {
            novaDx = 1;
            this.anguloRotacao = 0; // Direita
        } else if (keyCode === UP_ARROW) {
            novaDy = -1;
            this.anguloRotacao = -PI / 2; // Cima
        } else if (keyCode === DOWN_ARROW) {
            novaDy = 1;
            this.anguloRotacao = PI / 2; // Baixo
        }

        // Tentar mudar a direção imediatamente se possível
        if (this.podeMover(this.x + novaDx * this.velocidade, this.y + novaDy * this.velocidade)) {
            this.dx = novaDx;
            this.dy = novaDy;
        } else {
            // Se não puder, armazena para tentar na próxima célula
            this.proximoDx = novaDx;
            this.proximoDy = novaDy;
        }
    }

    update() {
        let proximoX = this.x + this.dx * this.velocidade;
        let proximoY = this.y + this.dy * this.velocidade;

        if (this.podeMover(proximoX, proximoY)) {
            this.x = proximoX;
            this.y = proximoY;
        } else {
            // Tenta a próxima direção se estiver no centro de uma célula
            let col = floor(this.x / larguraCelula);
            let row = floor(this.y / larguraCelula);
            if (abs(this.x - (col * larguraCelula + larguraCelula / 2)) < 1 && abs(this.y - (row * larguraCelula + larguraCelula / 2)) < 1) {
                // Se estiver bem centralizado na célula, tenta a direção agendada
                if (this.proximoDx !== 0 || this.proximoDy !== 0) {
                    if (this.podeMover(this.x + this.proximoDx * this.velocidade, this.y + this.proximoDy * this.velocidade)) {
                        this.dx = this.proximoDx;
                        this.dy = this.proximoDy;
                        this.proximoDx = 0;
                        this.proximoDy = 0;
                    }
                }
            }
            // Se não pode mover na direção atual nem na próxima, para
            if (!this.podeMover(proximoX, proximoY)) {
                 this.dx = 0;
                 this.dy = 0;
            }
        }

        // Animação da boca
        this.aberturaBoca += this.velocidadeBoca * this.direcaoAtualBoca;
        if (this.aberturaBoca > 1 || this.aberturaBoca < 0) {
            this.direcaoAtualBoca *= -1; // Inverte a direção da abertura
            this.aberturaBoca = constrain(this.aberturaBoca, 0, 1); // Garante que fique entre 0 e 1
        }

        // Lógica do poder
        if (this.estaComPoder) {
            this.tempoPoderRestante--;
            if (this.tempoPoderRestante <= 0) {
                this.estaComPoder = false;
                for (let fantasma of fantasmas) {
                    fantasma.setNormal(); // Retorna fantasmas ao normal
                }
            }
        }
    }

    show() {
        fill(255, 255, 0); // Amarelo
        noStroke();

        push();
        translate(this.x, this.y);
        rotate(this.anguloRotacao);

        let anguloBocaAtualInicial = map(this.aberturaBoca, 0, 1, 0, this.anguloInicialBoca);
        let anguloBocaAtualFinal = map(this.aberturaBoca, 0, 1, TWO_PI, this.anguloFinalBoca);

        arc(0, 0, this.raio * 2, this.raio * 2, anguloBocaAtualInicial, anguloBocaAtualFinal, PIE);
        pop();
    }

    // Checa se o Pac-Man pode mover para a próxima posição
    podeMover(targetX, targetY) {
        let offset = this.raio - 1; // Um pequeno offset para não "colar" nas paredes

        let topLeftX = floor((targetX - offset) / larguraCelula);
        let topLeftY = floor((targetY - offset) / larguraCelula);
        let bottomRightX = floor((targetX + offset) / larguraCelula);
        let bottomRightY = floor((targetY + offset) / larguraCelula);

        // Verifica todas as 4 "quinas" do Pac-Man
        if (labirinto[topLeftY][topLeftX] === 1 ||
            labirinto[topLeftY][bottomRightX] === 1 ||
            labirinto[bottomRightY][topLeftX] === 1 ||
            labirinto[bottomRightY][bottomRightX] === 1) {
            return false;
        }
        return true;
    }

    checarComida() {
        for (let i = comida.length - 1; i >= 0; i--) {
            let p = comida[i];
            if (!p.comido && dist(this.x, this.y, p.x, p.y) < this.raio + p.raio) {
                p.comido = true;
                score += p.isPowerPellet ? 50 : 10; // Pontuação diferente para power pellets
                if (p.isPowerPellet) {
                    this.ativarPoder();
                }
                // Tocar som de comer (se implementado)
                // somComer.play();
            }
        }
    }

    ativarPoder() {
        this.estaComPoder = true;
        this.tempoPoderRestante = this.duracaoPoder;
        for (let fantasma of fantasmas) {
            fantasma.setVulneravel(); // Fantasmas ficam vulneráveis
        }
    }

    colideCom(fantasma) {
        return dist(this.x, this.y, fantasma.x, fantasma.y) < this.raio + fantasma.raio;
    }
}

function criarPacMan() {
    // Encontrar a posição inicial do Pac-Man (pode ser hardcoded ou procurar no labirinto)
    // Para este exemplo, vamos definir uma posição inicial fixa:
    pacman = new PacMan(larguraCelula * 1.5, larguraCelula * 1.5); // Ajuste a posição inicial
}

function lidarColisaoPacManFantasma(fantasmaColidido) {
    if (pacman.estaComPoder) {
        // Pac-Man come o fantasma
        fantasmaColidido.foiComido();
        score += 200; // Pontuação por comer fantasma
    } else if (fantasmaColidido.estado !== "comido") {
        // Fantasma come Pac-Man
        vidas--;
        if (vidas > 0) {
            // Reiniciar Pac-Man e fantasmas para suas posições iniciais
            pacman.x = larguraCelula * 1.5;
            pacman.y = larguraCelula * 1.5;
            pacman.dx = 0;
            pacman.dy = 0;
            for (let fantasma of fantasmas) {
                fantasma.resetarPosicao();
                fantasma.setNormal(); // Garante que voltem ao normal
            }
        }
    }
}

// --- Fantasmas ---

class Fantasma {
    constructor(x, y, cor) {
        this.x = x;
        this.y = y;
        this.raio = larguraCelula / 2 - 2;
        this.velocidade = 1.5;
        this.dx = 0;
        this.dy = 0;
        this.corOriginal = cor;
        this.corAtual = cor;
        this.estado = "normal"; // "normal", "vulneravel", "comido"
        this.casaFantasmaX = x; // Posição de origem para reset
        this.casaFantasmaY = y;
    }

    show() {
        fill(this.corAtual);
        noStroke();
        ellipse(this.x, this.y, this.raio * 2, this.raio * 2);
        // Desenhar olhos e pupilas para dar mais detalhe
        fill(255); // Branco para os olhos
        ellipse(this.x - this.raio / 3, this.y - this.raio / 3, this.raio / 2, this.raio / 2);
        ellipse(this.x + this.raio / 3, this.y - this.raio / 3, this.raio / 2, this.raio / 2);

        fill(0); // Preto para as pupilas
        // Direção das pupilas (simplesmente para a direção do movimento)
        let pupilaXOffset = this.dx * this.raio / 6;
        let pupilaYOffset = this.dy * this.raio / 6;
        ellipse(this.x - this.raio / 3 + pupilaXOffset, this.y - this.raio / 3 + pupilaYOffset, this.raio / 4, this.raio / 4);
        ellipse(this.x + this.raio / 3 + pupilaXOffset, this.y - this.raio / 3 + pupilaYOffset, this.raio / 4, this.raio / 4);
    }

    update() {
        // Lógica de movimento dos fantasmas (pode ser mais complexa)
        // Para começar, um movimento aleatório ou seguindo o Pac-Man de forma básica.
        if (this.estado === "comido") {
            // Fantasma comido volta para a casa dos fantasmas
            this.moverParaCasa();
        } else if (this.estado === "vulneravel") {
            // Movimento de fuga (oposto ao Pac-Man)
            this.fugirDoPacMan();
        } else {
            // Movimento de perseguição (simples)
            this.perseguirPacMan();
        }

        let proximoX = this.x + this.dx * this.velocidade;
        let proximoY = this.y + this.dy * this.velocidade;

        if (this.podeMover(proximoX, proximoY)) {
            this.x = proximoX;
            this.y = proximoY;
        } else {
            // Se colidiu com parede, escolhe uma nova direção aleatória
            this.escolherNovaDirecao();
        }
    }

    podeMover(targetX, targetY) {
        let offset = this.raio - 1;

        let topLeftX = floor((targetX - offset) / larguraCelula);
        let topLeftY = floor((targetY - offset) / larguraCelula);
        let bottomRightX = floor((targetX + offset) / larguraCelula);
        let bottomRightY = floor((targetY + offset) / larguraCelula);

        if (labirinto[topLeftY][topLeftX] === 1 ||
            labirinto[topLeftY][bottomRightX] === 1 ||
            labirinto[bottomRightY][topLeftX] === 1 ||
            labirinto[bottomRightY][bottomRightX] === 1) {
            return false;
        }
        return true;
    }

    escolherNovaDirecao() {
        let direcoesValidas = [];
        let currentX = floor(this.x / larguraCelula);
        let currentY = floor(this.y / larguraCelula);

        // Tenta mover para cima
        if (currentY > 0 && labirinto[currentY - 1][currentX] !== 1 && this.dy !== 1) { // Evita voltar imediatamente
            direcoesValidas.push({ dx: 0, dy: -1 });
        }
        // Tenta mover para baixo
        if (currentY < linhas - 1 && labirinto[currentY + 1][currentX] !== 1 && this.dy !== -1) {
            direcoesValidas.push({ dx: 0, dy: 1 });
        }
        // Tenta mover para a esquerda
        if (currentX > 0 && labirinto[currentY][currentX - 1] !== 1 && this.dx !== 1) {
            direcoesValidas.push({ dx: -1, dy: 0 });
        }
        // Tenta mover para a direita
        if (currentX < colunas - 1 && labirinto[currentY][currentX + 1] !== 1 && this.dx !== -1) {
            direcoesValidas.push({ dx: 1, dy: 0 });
        }

        if (direcoesValidas.length > 0) {
            let escolha = random(direcoesValidas);
            this.dx = escolha.dx;
            this.dy = escolha.dy;
        } else {
            // Se estiver preso, tenta uma direção aleatória (pode acontecer em labirintos complexos)
            this.dx = random([-1, 0, 1]);
            this.dy = random([-1, 0, 1]);
            if (this.dx !== 0 && this.dy !== 0) { // Garante movimento horizontal ou vertical
                this.dy = 0;
            }
        }
    }

    perseguirPacMan() {
        // Implementação básica: simplesmente se move em direção ao Pac-Man
        // Isso fará com que eles se prendam em paredes se não houver um algoritmo de pathfinding
        let dirX = 0;
        let dirY = 0;

        if (pacman.x > this.x) {
            dirX = 1;
        } else if (pacman.x < this.x) {
            dirX = -1;
        }

        if (pacman.y > this.y) {
            dirY = 1;
        } else if (pacman.y < this.y) {
            dirY = -1;
        }

        // Tenta mover na direção horizontal preferencialmente, depois vertical
        if (dirX !== 0 && this.podeMover(this.x + dirX * this.velocidade, this.y)) {
            this.dx = dirX;
            this.dy = 0;
        } else if (dirY !== 0 && this.podeMover(this.x, this.y + dirY * this.velocidade)) {
            this.dx = 0;
            this.dy = dirY;
        } else {
            this.escolherNovaDirecao(); // Se não pode ir na direção do Pac-Man, escolhe aleatoriamente
        }
    }

    fugirDoPacMan() {
        let dirX = 0;
        let dirY = 0;

        if (pacman.x > this.x) {
            dirX = -1; // Foge para a esquerda
        } else if (pacman.x < this.x) {
            dirX = 1; // Foge para a direita
        }

        if (pacman.y > this.y) {
            dirY = -1; // Foge para cima
        } else if (pacman.y < this.y) {
            dirY = 1; // Foge para baixo
        }

        // Tenta mover na direção horizontal de fuga preferencialmente, depois vertical
        if (dirX !== 0 && this.podeMover(this.x + dirX * this.velocidade, this.y)) {
            this.dx = dirX;
            this.dy = 0;
        } else if (dirY !== 0 && this.podeMover(this.x, this.y + dirY * this.velocidade)) {
            this.dx = 0;
            this.dy = dirY;
        } else {
            this.escolherNovaDirecao(); // Se não pode fugir diretamente, escolhe aleatoriamente
        }
    }

    setVulneravel() {
        this.estado = "vulneravel";
        this.corAtual = color(0, 0, 150); // Azul escuro
        this.velocidade = 1; // Fica mais lento
    }

    setNormal() {
        this.estado = "normal";
        this.corAtual = this.corOriginal;
        this.velocidade = 1.5;
    }

    foiComido() {
        this.estado = "comido";
        this.corAtual = color(100); // Cinza para fantasmas comidos
        this.velocidade = 4; // Volta rápido para a casa
    }

    moverParaCasa() {
        let distAtual = dist(this.x, this.y, this.casaFantasmaX, this.casaFantasmaY);
        if (distAtual < this.velocidade) {
            this.x = this.casaFantasmaX;
            this.y = this.casaFantasmaY;
            this.setNormal(); // Retorna ao normal quando chega em casa
            this.dx = 0;
            this.dy = 0; // Para de se mover na casa
        } else {
            // Movimento direto para a casa
            let angle = atan2(this.casaFantasmaY - this.y, this.casaFantasmaX - this.x);
            this.dx = cos(angle);
            this.dy = sin(angle);
        }
    }

    resetarPosicao() {
        this.x = this.casaFantasmaX;
        this.y = this.casaFantasmaY;
        this.dx = 0;
        this.dy = 0;
        this.setNormal();
    }
}

function criarFantasmas() {
    // Posições iniciais dos fantasmas (ajuste conforme seu labirinto)
    // Cores clássicas: Blinky (vermelho), Pinky (rosa), Inky (azul), Clyde (laranja)
    fantasmas.push(new Fantasma(larguraCelula * 15, larguraCelula * 9, color(255, 0, 0))); // Blinky (vermelho)
    fantasmas.push(new Fantasma(larguraCelula * 13, larguraCelula * 9, color(255, 192, 203))); // Pinky (rosa)
    fantasmas.push(new Fantasma(larguraCelula * 17, larguraCelula * 9, color(0, 255, 255))); // Inky (ciano)
    fantasmas.push(new Fantasma(larguraCelula * 11, larguraCelula * 9, color(255, 165, 0))); // Clyde (laranja)

    // Inicializa a direção de cada fantasma
    for (let fantasma of fantasmas) {
        fantasma.escolherNovaDirecao();
    }
}