function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let telaAtual = 0; // 0: Início, 1: Jogo, 2: Fim de Jogo

// Variáveis do jogo
let score = 0;
let tempoRestante = 60; // 60 segundos por rodada
let barraCampo = 100; // 0-100
let barraCidade = 100; // 0-100

// Arrays para armazenar os itens que aparecem
let itensCampo = [];
let itensCidade = [];

// Temporizadores para o aparecimento dos itens
let timerCampo;
let timerCidade;

function setup() {
  createCanvas(800, 600);
  // Inicializa os temporizadores para aparecerem itens
  timerCampo = setInterval(gerarItemCampo, 3000); // A cada 3 segundos
  timerCidade = setInterval(gerarItemCidade, 4000); // A cada 4 segundos
}

function draw() {
  background(220); // Cor de fundo padrão

  if (telaAtual === 0) {
    telaInicio();
  } else if (telaAtual === 1) {
    telaJogo();
  } else if (telaAtual === 2) {
    telaFimDeJogo();
  }
}

function mousePressed() {
  if (telaAtual === 0) {
    // Botão Iniciar Jogo
    if (mouseX > width / 2 - 50 && mouseX < width / 2 + 50 && mouseY > height / 2 && mouseY < height / 2 + 40) {
      telaAtual = 1;
      score = 0;
      tempoRestante = 60;
      barraCampo = 100;
      barraCidade = 100;
      // Reinicia timers de itens
      clearInterval(timerCampo);
      clearInterval(timerCidade);
      timerCampo = setInterval(gerarItemCampo, 3000);
      timerCidade = setInterval(gerarItemCidade, 4000);
      // Inicia o cronômetro do jogo
      setInterval(atualizarTempo, 1000);
    }
    // Botão Como Jogar (implementar lógica de tela de ajuda aqui)
    if (mouseX > width / 2 - 70 && mouseX < width / 2 + 70 && mouseY > height / 2 + 60 && mouseY < height / 2 + 100) {
      // Implementar tela de instruções ou um modal
      alert("Como Jogar:\nClique nos itens do campo para enviá-los à cidade e vice-versa. Mantenha as barras de necessidade cheias!");
    }
  } else if (telaAtual === 1) {
    // Lógica de clique no jogo
    // Clicou em item do campo
    for (let i = itensCampo.length - 1; i >= 0; i--) {
      let item = itensCampo[i];
      if (dist(mouseX, mouseY, item.x, item.y) < 20) { // Raio de clique do item
        // Animação de transporte para a cidade
        animarTransporte(item, "campoParaCidade");
        itensCampo.splice(i, 1); // Remove o item clicado
        score += 10;
        break;
      }
    }

    // Clicou em item da cidade
    for (let i = itensCidade.length - 1; i >= 0; i--) {
      let item = itensCidade[i];
      if (dist(mouseX, mouseY, item.x, item.y) < 20) { // Raio de clique do item
        // Animação de transporte para o campo
        animarTransporte(item, "cidadeParaCampo");
        itensCidade.splice(i, 1); // Remove o item clicado
        score += 10;
        break;
      }
    }
  } else if (telaAtual === 2) {
    // Botão Jogar Novamente
    if (mouseX > width / 2 - 70 && mouseX < width / 2 + 70 && mouseY > height / 2 + 50 && mouseY < height / 2 + 90) {
      telaAtual = 0; // Volta para a tela de início
    }
  }
}

// --- Telas do Jogo ---

function telaInicio() {
  textAlign(CENTER, CENTER);
  textSize(48);
  fill(50);
  text("Agrinho 2025: Conexão Campo-Cidade", width / 2, height / 3);

  // Botão Iniciar Jogo
  fill(76, 175, 80); // Verde
  rect(width / 2 - 75, height / 2, 150, 40, 10);
  fill(255);
  textSize(24);
  text("Iniciar Jogo", width / 2, height / 2 + 20);

  // Botão Como Jogar
  fill(33, 150, 243); // Azul
  rect(width / 2 - 75, height / 2 + 60, 150, 40, 10);
  fill(255);
  textSize(20);
  text("Como Jogar", width / 2, height / 2 + 80);
}

function telaJogo() {
  // Desenha o cenário
  desenharCenario();

  // Desenha os itens do campo
  for (let item of itensCampo) {
    desenharItem(item.x, item.y, item.tipo);
  }

  // Desenha os itens da cidade
  for (let item of itensCidade) {
    desenharItem(item.x, item.y, item.tipo);
  }

  // Desenha as barras de necessidade
  desenharBarrasNecessidade();

  // Desenha a pontuação e o tempo
  fill(0);
  textSize(20);
  textAlign(LEFT, TOP);
  text("Pontuação: " + score, 20, 20);
  textAlign(RIGHT, TOP);
  text("Tempo: " + tempoRestante + "s", width - 20, 20);

  // Lógica de fim de jogo
  if (tempoRestante <= 0 || barraCampo <= 0 || barraCidade <= 0) {
    telaAtual = 2;
  }

  // Diminui as barras de necessidade gradualmente
  if (frameCount % 60 === 0) { // A cada segundo
    barraCampo -= 1;
    barraCidade -= 1;
    barraCampo = constrain(barraCampo, 0, 100);
    barraCidade = constrain(barraCidade, 0, 100);
  }
}

function telaFimDeJogo() {
  textAlign(CENTER, CENTER);
  textSize(48);
  fill(50);
  if (tempoRestante <= 0 && barraCampo > 0 && barraCidade > 0) {
    text("Parabéns! Você conectou o Campo e a Cidade!", width / 2, height / 3);
  } else {
    text("Fim de Jogo!", width / 2, height / 3);
  }

  textSize(32);
  text("Sua Pontuação Final: " + score, width / 2, height / 2 - 20);

  // Botão Jogar Novamente
  fill(76, 175, 80); // Verde
  rect(width / 2 - 75, height / 2 + 50, 150, 40, 10);
  fill(255);
  textSize(24);
  text("Jogar Novamente", width / 2, height / 2 + 70);
}

// --- Funções de Desenho ---

function desenharCenario() {
  // Lado do Campo (verde)
  fill(139, 195, 74);
  rect(0, 0, width / 2, height);

  // Lado da Cidade (cinza)
  fill(158, 158, 158);
  rect(width / 2, 0, width / 2, height);

  // Linha de Conexão (estrada ou rio)
  fill(60); // Estrada escura
  rect(width / 2 - 10, 0, 20, height); // Uma "estrada" central

  // Desenhar alguns elementos visuais fixos
  // Campo: Celeiro, árvores
  fill(121, 85, 72); // Marrom
  rect(width / 4 - 30, height - 100, 60, 80); // Celeiro simples
  fill(76, 175, 80); // Verde da árvore
  ellipse(width / 4 + 50, height - 150, 40, 40); // Árvore simples

  // Cidade: Prédios
  fill(96, 125, 139); // Cinza azulado
  rect(width * 3 / 4 - 40, height - 120, 80, 100); // Prédio simples
  rect(width * 3 / 4 + 20, height - 150, 60, 130); // Outro prédio
}

function desenharBarrasNecessidade() {
  // Barra Campo
  fill(255);
  rect(20, 50, 150, 20); // Fundo da barra
  fill(76, 175, 80); // Verde
  rect(20, 50, map(barraCampo, 0, 100, 0, 150), 20); // Preenchimento
  fill(0);
  textSize(14);
  text("Campo", 20, 45);

  // Barra Cidade
  fill(255);
  rect(width - 170, 50, 150, 20); // Fundo da barra
  fill(33, 150, 243); // Azul
  rect(width - 170, 50, map(barraCidade, 0, 100, 0, 150), 20); // Preenchimento
  fill(0);
  text("Cidade", width - 170, 45);
}

function desenharItem(x, y, tipo) {
  // Usar switch para desenhar diferentes tipos de itens
  switch (tipo) {
    case "milho":
      fill(255, 235, 59); // Amarelo milho
      ellipse(x, y, 30, 30);
      fill(0);
      textSize(12);
      text("Milho", x, y + 20);
      break;
    case "leite":
      fill(255); // Branco leite
      rect(x - 15, y - 20, 30, 40); // Caixa de leite simples
      fill(0);
      text("Leite", x, y + 20);
      break;
    case "pao":
      fill(255, 193, 7); // Marrom pão
      ellipse(x, y, 40, 30);
      fill(0);
      text("Pão", x, y + 20);
      break;
    case "livro":
      fill(100, 100, 200); // Azul livro
      rect(x - 10, y - 15, 20, 30);
      fill(0);
      text("Livro", x, y + 20);
      break;
      // Adicionar mais tipos de itens aqui
  }
}

// --- Funções de Lógica do Jogo ---

function gerarItemCampo() {
  if (telaAtual === 1) {
    let x = random(50, width / 2 - 50);
    let y = random(100, height - 100);
    let tipos = ["milho", "leite"]; // Adicionar mais tipos
    let tipoAleatorio = random(tipos);
    itensCampo.push({
      x: x,
      y: y,
      tipo: tipoAleatorio,
      state: "aparecendo" // Estado para animação, se necessário
    });
  }
}

function gerarItemCidade() {
  if (telaAtual === 1) {
    let x = random(width / 2 + 50, width - 50);
    let y = random(100, height - 100);
    let tipos = ["pao", "livro"]; // Adicionar mais tipos
    let tipoAleatorio = random(tipos);
    itensCidade.push({
      x: x,
      y: y,
      tipo: tipoAleatorio,
      state: "aparecendo"
    });
  }
}

function animarTransporte(item, direcao) {
  // Esta função simularia a animação do item indo de um lado para o outro.
  // Poderíamos usar um loop for para desenhar o item em posições intermediárias
  // ao longo do tempo, ou usar uma biblioteca de animação.
  // Por simplicidade, aqui apenas atualizamos as barras de necessidade.

  if (direcao === "campoParaCidade") {
    barraCidade = constrain(barraCidade + 5, 0, 100); // Aumenta a barra da cidade
  } else if (direcao === "cidadeParaCampo") {
    barraCampo = constrain(barraCampo + 5, 0, 100); // Aumenta a barra do campo
  }
  // console.log(`Item ${item.tipo} transportado. Barra Campo: ${barraCampo}, Barra Cidade: ${barraCidade}`);
}

function atualizarTempo() {
  if (telaAtual === 1) {
    tempoRestante--;
  }
}